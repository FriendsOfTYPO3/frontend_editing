.. include:: ../Includes.txt

.. highlight:: rst

===========
Development
===========

Instructions on how to develop the frontend editing extension

.. toctree::
   :titlesonly:

   Dependencies/Index
   Workflow/Index
   Hooks/Index